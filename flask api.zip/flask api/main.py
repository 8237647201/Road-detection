import datetime
from flask import Flask,jsonify,render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URL'] = 'sqlite:///test.db'
db = SQLAlchemy(app)

class Todo(db.Model):
    id = db.column(db.Integer, primary_key=True)
    content = db.column(db.string(200), nullable = False)
    
    date_created = db.column(db.DateTime, default =datetime.utcnow)
    
    def __repr__(self):
        return '<Task %r>' % self.id
@app.route('/')
def hello_world(): 
    return render_template('index.html')

if __name__ == "__main__":
   app.run(debug=True)
